// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyD7ZW3ItqJYLWWk20YIxOxQL_mbx1oX1Rs",
  authDomain: "vmc-online.firebaseapp.com",
  projectId: "vmc-online",
  storageBucket: "vmc-online.appspot.com",
  messagingSenderId: "160872957121",
  appId: "1:160872957121:web:256027a0d658f8f1094040",
  measurementId: "G-RF1PY9YDQF"
};